ЗОМБИ АРЕНА 1000
Максимально простой способ:
1. Распакуйте ZIP.
2. Откройте папку в Android Studio.
3. Дождитесь Gradle Sync.
4. Build -> Build APK(s).
5. APK будет в app/build/outputs/apk/debug/app-debug.apk

Игра офлайн. Прогресс сохраняется в localStorage.
1000 уровней, 8 волн на уровень, скины, оружие, улучшения, звуки и фоновая музыка.
